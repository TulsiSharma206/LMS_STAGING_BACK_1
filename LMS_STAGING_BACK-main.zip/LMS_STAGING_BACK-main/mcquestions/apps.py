from django.apps import AppConfig


class McquestionsConfig(AppConfig):
    name = 'mcquestions'
    verbose_name = 'MCQ Questions'
