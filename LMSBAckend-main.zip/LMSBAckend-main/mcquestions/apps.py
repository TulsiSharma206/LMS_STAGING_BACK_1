from django.apps import AppConfig


class McquestionsConfig(AppConfig):
    name = 'mcquestions'
