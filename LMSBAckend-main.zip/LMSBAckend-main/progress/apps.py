from django.apps import AppConfig


class ProgressConfig(AppConfig):
    name = 'progress'
