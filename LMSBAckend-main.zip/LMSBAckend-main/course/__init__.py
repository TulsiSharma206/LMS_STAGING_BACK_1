default_app_config = 'course.apps.CourseConfig'
